import javax.swing.*;


public class Main {

    public static void main(String[] args) {

        // SE SUPONE ESTO CREA LA VENTANA LOGIN
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameLogin = new LogIn();
                frameLogin.setSize(450, 300);
                frameLogin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameLogin.setLocationRelativeTo(null);
                frameLogin.setVisible(true);
            }
        });
    }
}

