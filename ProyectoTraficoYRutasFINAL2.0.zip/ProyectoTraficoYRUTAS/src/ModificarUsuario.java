import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ModificarUsuario extends JFrame{
    private JPanel panel1;
    private JTextField txtNombreUsuario;
    private JTextField txtNuevaContraseña;
    private JButton btnModificar;
    private JButton btnMenuGU;
    private JLabel lblTitulo;
    private JLabel lblTitulo2;
    private JLabel lblNombreUsuario;
    private JLabel lblNuevaContraseña;
    private JLabel lblEsAdmin;
    private JCheckBox checkBoxAdmin;

    public ModificarUsuario() {
        super("MODIFICAR USUARIO");
        setContentPane(panel1);

        btnModificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modificarDatos();
            }
        });

        btnMenuGU.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BackTOMenu();
            }
        });
    }
    private void modificarDatos() {
        ControlAcceso controlAcceso = ControlAcceso.obtenerInstancia();

        boolean esAdmin = checkBoxAdmin.isSelected();
        String nombreUsuario = txtNombreUsuario.getText();
        String nuevaContraseña = txtNuevaContraseña.getText();

        if (nombreUsuario.isEmpty() || nuevaContraseña.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Los campos obligatorios no pueden estar vacíos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (esAdmin) {
            JOptionPane.showMessageDialog(this, "El usuario es administrador");
        }

        controlAcceso.modificarUsuario(nombreUsuario, nuevaContraseña, esAdmin);
        JOptionPane.showMessageDialog(null,"Usuario modificado exitosamente.");
        txtNombreUsuario.setText("");
        txtNuevaContraseña.setText("");
        checkBoxAdmin.setSelected(false);
    }

    private void BackTOMenu(){
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameMenuGU = new GestionarUsuarios();
                frameMenuGU.setSize(400, 350);
                frameMenuGU.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameMenuGU.setLocationRelativeTo(null);
                frameMenuGU.setVisible(true);
                dispose();
            }
        });
    }
}
