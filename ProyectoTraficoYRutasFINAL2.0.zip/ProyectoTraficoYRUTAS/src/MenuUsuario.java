import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuUsuario extends JFrame {
    private JPanel panel1;
    private JLabel lblMainMenuUsuario;
    private JTextField opcionSeleccionada;
    private JLabel lblOpcion1;
    private JLabel lblOpcion2;
    private JLabel lblOpcionSalir;
    private JLabel lblOrden1;
    private JButton btnSeleccion;

    public MenuUsuario() {
        super("MENU USUARIO");
        setContentPane(panel1);

        opcionSeleccionada.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String opcionU = opcionSeleccionada.getText();
                switch (opcionU) {
                    case "1":
                        mostrarInformacionTrafico();
                        break;
                    case "2":
                        mostrarRutasOptimas();
                        break;
                    case "0":
                        salir();
                        break;
                    default:
                        JOptionPane.showMessageDialog(null,"Opción no válida. Por favor, elija una opción del menú.");
                }
            }
        });
    }

    private void mostrarInformacionTrafico() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameConsInfo = new ConsultaInfo();
                frameConsInfo.setSize(400, 400);
                frameConsInfo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameConsInfo.setLocationRelativeTo(null);
                frameConsInfo.setVisible(true);
                dispose();
            }
        });
    }

    private void mostrarRutasOptimas() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameConsRO = new ConsultaRutaOptima();
                frameConsRO.setSize(400, 400);
                frameConsRO.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameConsRO.setLocationRelativeTo(null);
                frameConsRO.setVisible(true);
                dispose();
            }
        });
    }

    private void salir(){
        JOptionPane.showMessageDialog(null,"Saliendo del usuario actual...");
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameSalida = new Salida();
                frameSalida.setSize(350, 300);
                frameSalida.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameSalida.setLocationRelativeTo(null);
                frameSalida.setVisible(true);
                dispose();
            }
        });
    }
}

