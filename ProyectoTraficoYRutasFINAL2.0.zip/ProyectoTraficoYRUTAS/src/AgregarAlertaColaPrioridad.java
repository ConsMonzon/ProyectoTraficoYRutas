import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AgregarAlertaColaPrioridad extends JFrame{
    private JPanel panel1;
    private JTextField txtTipoAlerta;
    private JTextField txtDescripAlerta;
    private JButton btnAgregarACP;
    private JButton btnMenuAdmin;
    private JLabel lblTitulo;
    private JLabel lblTitulo2;
    private JLabel lblTipoAlerta;
    private JLabel lblDescripAlerta;

    public AgregarAlertaColaPrioridad() {
        //TITULO DE LA VENTANA
        super("AGREGAR ALERTA COLA PRIORIDAD");
        setContentPane(panel1);
        btnAgregarACP.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarACP();
            }
        });
        btnMenuAdmin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BackTOMenu();
            }
        });

    }
    private void agregarACP(){
        ColaPrioridadAlertas colaAlertas = DatosCompartidos.obtenerColaAlertas();
        GrafoPonderado grafo = DatosCompartidos.obtenerGrafoPonderado();

        String tipoAlerta = txtTipoAlerta.getText();
        String descripAlerta = txtDescripAlerta.getText();


        if (tipoAlerta.isEmpty() || descripAlerta.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Los campos obligatorios no pueden estar vacíos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        colaAlertas.agregarAlerta(new ColaPrioridadAlertas.Alerta(tipoAlerta, descripAlerta));
        JOptionPane.showMessageDialog(null,"Alerta agregada a la cola de prioridad.");
        txtTipoAlerta.setText("");
        txtDescripAlerta.setText("");
    }

    private void BackTOMenu(){
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameMenuAdmin = new MenuAdmin();
                frameMenuAdmin.setSize(350, 300);
                frameMenuAdmin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameMenuAdmin.setLocationRelativeTo(null);
                frameMenuAdmin.setVisible(true);
                dispose();
            }
        });
    }
}

