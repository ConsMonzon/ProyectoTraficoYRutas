import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LogIn extends JFrame {
    private JPanel panel1;
    private JLabel lblUsuario;
    private JTextField txtUsuario;
    private JLabel lblcontraseña;
    private JPasswordField txtContraseña;
    private JButton btnLogIn;

    public LogIn() {
        super("LOG IN");
        setContentPane(panel1);

        btnLogIn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }

            private void login(){
                String usuario = txtUsuario.getText();
                String contraseña = new String(txtContraseña.getPassword());

                ControlAcceso controlAcceso = ControlAcceso.obtenerInstancia();

                if (controlAcceso.verificarCredenciales(usuario, contraseña)) {
                    controlAcceso.setUsuarioActual(usuario);
                    if (controlAcceso.esAdministrador(usuario)) {
                        mostrarMenuAdministrador();
                    } else {
                        mostrarMenuUsuario();
                    }
                } else {
                    JOptionPane.showMessageDialog(LogIn.this, "Credenciales incorrectas. Intente nuevamente...");
                }
            }

            private void mostrarMenuUsuario() {
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        JFrame frameUsuario = new MenuUsuario();
                        frameUsuario.setSize(350, 300);
                        frameUsuario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        frameUsuario.setLocationRelativeTo(null);
                        frameUsuario.setVisible(true);
                        dispose();
                    }
                });
            }

            private void mostrarMenuAdministrador() {
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        JFrame frameMenuAdmin = new MenuAdmin();
                        frameMenuAdmin.setSize(350, 300);
                        frameMenuAdmin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        frameMenuAdmin.setLocationRelativeTo(null);
                        frameMenuAdmin.setVisible(true);

                        // Cierra la ventana actual (Login)
                        dispose();
                    }
                });
            }
        });
    }
}
