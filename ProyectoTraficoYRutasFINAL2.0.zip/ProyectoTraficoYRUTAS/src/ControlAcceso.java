import java.util.HashMap;
import java.util.Map;

public class ControlAcceso {
    private static ControlAcceso instancia;
    private Map<String, Usuario> usuarios;
    private String usuarioActual;

    public ControlAcceso() {
        usuarios = new HashMap<>();
        // Agregar usuarios de ejemplo
        inicializarUsuarios();
    }

    public static ControlAcceso obtenerInstancia() {
        if (instancia == null) {
            instancia = new ControlAcceso();
        }
        return instancia;
    }

    // Método para agregar un nuevo usuario al sistema
    public void agregarUsuario(String nombreUsuario, String contraseña, boolean esAdmin) {
        usuarios.put(nombreUsuario, new Usuario(nombreUsuario, contraseña, esAdmin));
    }

    public void modificarUsuario(String nombreUsuario, String nuevaContraseña, boolean esAdmin) {
        if (usuarios.containsKey(nombreUsuario)) {
            Usuario usuarioExistente = usuarios.get(nombreUsuario);
            usuarioExistente.setContraseña(nuevaContraseña);
            usuarioExistente.setEsAdmin(esAdmin);
            usuarios.put(nombreUsuario, usuarioExistente);
            System.out.println("Usuario modificado exitosamente.");
        } else {
            System.out.println("El usuario especificado no existe.");
        }
    }

    public void eliminarUsuario(String nombreUsuario) {
        usuarios.remove(nombreUsuario);
    }
    // Método para verificar las credenciales de inicio de sesión
    public boolean verificarCredenciales(String nombreUsuario, String contraseña) {
        if (usuarios.containsKey(nombreUsuario)) {
            Usuario usuario = usuarios.get(nombreUsuario);
            return usuario.getContraseña().equals(contraseña);
        }
        return false;
    }

    // Método para verificar si un usuario es administrador
    public boolean esAdministrador(String nombreUsuario) {
        if (usuarios.containsKey(nombreUsuario)) {
            Usuario usuario = usuarios.get(nombreUsuario);
            return usuario.esAdmin();
        }
        return false;
    }

    // Inicializar algunos usuarios de ejemplo
    private void inicializarUsuarios() {
        agregarUsuario("usuario1", "contraseña1", false);
        agregarUsuario("admin", "admin123", true);
        // Puedes agregar más usuarios según sea necesario
    }

    // Clase para representar un usuario
    private class Usuario {
        private String nombreUsuario;
        private String contraseña;
        private boolean esAdmin;

        public Usuario(String nombreUsuario, String contraseña, boolean esAdmin) {
            this.nombreUsuario = nombreUsuario;
            this.contraseña = contraseña;
            this.esAdmin = esAdmin;
        }

        public void setContraseña(String contraseña) {
            this.contraseña = contraseña;
        }
        public void setEsAdmin(boolean esAdmin) {
            this.esAdmin = esAdmin;
        }

        public String getContraseña() {
            return contraseña;
        }

        public boolean esAdmin() {
            return esAdmin;
        }
    }

    public void setUsuarioActual(String nombreUsuario) {
        this.usuarioActual = nombreUsuario;
    }

    public String getUsuarioActual() {
        return usuarioActual;
    }


}