import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ConsultaInfo extends JFrame {
    private JPanel panel1;
    private JTextField txtRuta;
    private JLabel lblTitulo;
    private JLabel lblIngresa;
    private JLabel lblConsulta;
    private JTable table1;
    private JLabel lblTitulo2;
    private JButton btnConsulta;
    private JButton btnMenu;

    private DefaultTableModel tableModel; // Nuevo: Modelo de la tabla

    public ConsultaInfo() {
        super("CONSULTA INFO");
        setContentPane(panel1);

        // Inicializar modelo de la tabla
        String[] columnNames = {"RUTA", "VELOCIDAD TRAFICO", "DENSIDAD VEHICULOS", "¿ACCIDENTE?"};
        tableModel = new DefaultTableModel(null, columnNames);
        table1.setModel(tableModel);

        btnConsulta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Consulta();
            }
        });

        btnMenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ControlAcceso controlAcceso = ControlAcceso.obtenerInstancia();
                String usuario = controlAcceso.getUsuarioActual();
                BackTOMenu(controlAcceso.esAdministrador(usuario));
            }
        });
    }

    private void Consulta() {
        TablaHashTrafico tablaHashTrafico = DatosCompartidos.obtenerTablaHashTrafico();

        // Limpiar la tabla antes de realizar una nueva consulta
        tableModel.setRowCount(0);

        String rutaConsulta = txtRuta.getText();
        TablaHashTrafico.InformacionTrafico info = tablaHashTrafico.obtenerDatos(rutaConsulta);

        if (info != null) {
            // Actualizar el modelo de la tabla con los nuevos datos
            Object[] rowData = {rutaConsulta, info.obtenerVelocidadTrafico(), info.obtenerDensidadVehiculos(), info.hayAccidente()};
            tableModel.addRow(rowData);
        } else {
            JOptionPane.showMessageDialog(null, "No hay información para la ruta especificada.");
        }

        txtRuta.setText("");
    }
    private void BackTOMenu(boolean esAdmin) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                if (esAdmin) {
                    JFrame frameMenuAdmin = new MenuAdmin();
                    frameMenuAdmin.setSize(350, 300);
                    frameMenuAdmin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    frameMenuAdmin.setLocationRelativeTo(null);
                    frameMenuAdmin.setVisible(true);
                } else {
                    JFrame frameMenuUsuario = new MenuUsuario();
                    frameMenuUsuario.setSize(350, 300);
                    frameMenuUsuario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    frameMenuUsuario.setLocationRelativeTo(null);
                    frameMenuUsuario.setVisible(true);
                }
                dispose();
            }
        });
    }
}
