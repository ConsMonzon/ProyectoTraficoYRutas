import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EliminarUsuario extends JFrame{
    private JPanel panel1;
    private JButton btnEliminar;
    private JLabel lblTitulo;
    private JTextField txtUsuario;
    private JLabel lblOrden;
    private JButton btnMenuGU;
    private JLabel lblTitulo2;

    public EliminarUsuario() {
        super("ELIMINAR USUARIO");
        setContentPane(panel1);

        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarDatos();
            }
        });

        btnMenuGU.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BackTOMenu();
            }
        });
    }
    private void agregarDatos() {
        ControlAcceso controlAcceso = ControlAcceso.obtenerInstancia();

        String usuarioEliminar = txtUsuario.getText();

        if (usuarioEliminar.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El campos es obligatorio no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        controlAcceso.eliminarUsuario(usuarioEliminar);
        JOptionPane.showMessageDialog(null,"Usuario eliminado exitosamente.");
        txtUsuario.setText("");
    }

    private void BackTOMenu(){
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameMenuGU = new GestionarUsuarios();
                frameMenuGU.setSize(400, 350);
                frameMenuGU.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameMenuGU.setLocationRelativeTo(null);
                frameMenuGU.setVisible(true);
                dispose();
            }
        });
    }
}
