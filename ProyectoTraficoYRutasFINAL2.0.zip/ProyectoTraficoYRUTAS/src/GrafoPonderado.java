import java.util.*;

public class GrafoPonderado {
    private int V; // Número de vértices
    private List<List<Nodo>> adjList; // Lista de adyacencia para representar el grafo ponderado

    public GrafoPonderado(int vertices) {
        V = vertices;
        adjList = new ArrayList<>();
        for (int i = 0; i < V; i++) {
            adjList.add(new ArrayList<>());
        }
    }

    // Clase para representar el nodo con su peso
    class Nodo {
        int destino;
        int peso;

        Nodo(int destino, int peso) {
            this.destino = destino;
            this.peso = peso;
        }
    }

    // Agregar una arista ponderada al grafo dirigido
    public void agregarArista(int origen, int destino, int peso) {
        adjList.get(origen).add(new Nodo(destino, peso));
    }

    // Método para encontrar la ruta más eficiente utilizando Dijkstra
    public List<Integer> encontrarRutaEficiente(int origen, int destino) {
        PriorityQueue<Nodo> colaPrioridad = new PriorityQueue<>(V, Comparator.comparingInt(a -> a.peso));

        int[] distancias = new int[V];
        Arrays.fill(distancias, Integer.MAX_VALUE);

        int[] previos = new int[V];
        Arrays.fill(previos, -1);

        boolean[] visitado = new boolean[V];

        distancias[origen] = 0;
        colaPrioridad.offer(new Nodo(origen, 0));

        while (!colaPrioridad.isEmpty()) {
            int u = colaPrioridad.poll().destino;
            visitado[u] = true;

            for (Nodo vecino : adjList.get(u)) {
                int v = vecino.destino;
                int peso = vecino.peso;

                if (!visitado[v] && distancias[u] != Integer.MAX_VALUE && distancias[u] + peso < distancias[v]) {
                    distancias[v] = distancias[u] + peso;
                    previos[v] = u;
                    colaPrioridad.offer(new Nodo(v, distancias[v]));
                }
            }
        }

        // Reconstruir la ruta más eficiente
        List<Integer> ruta = new ArrayList<>();
        for (int i = destino; i != -1; i = previos[i]) {
            ruta.add(i);
        }
        Collections.reverse(ruta);

        return ruta;
    }
}