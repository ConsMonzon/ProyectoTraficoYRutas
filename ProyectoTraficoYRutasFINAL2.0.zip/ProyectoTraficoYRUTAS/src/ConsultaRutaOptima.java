import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ConsultaRutaOptima extends JFrame {
    private JPanel panel1;
    private JLabel lblTitulo;
    private JTextField txtOrigen;
    private JTextField txtDestino;
    private JLabel lblOrigen;
    private JLabel lblDestino;
    private JLabel lblConsulta;
    private JList<String> list1;
    private JButton btnConsulta;
    private JButton btnMenuUsuario;
    private JLabel lblTitulo2;
    private JButton btnNuevo;
    private DefaultListModel<String> listModel;

    public ConsultaRutaOptima() {
        super("CONSULTA RUTA ÓPTIMA");
        setContentPane(panel1);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Inicializar el modelo de la lista
        listModel = new DefaultListModel<>();
        list1.setModel(listModel);

        btnConsulta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ConsultaRO();
            }
        });

        btnMenuUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BackTOMenu();
            }
        });

        pack();
    }



    private void ConsultaRO(){
        //listModel.clear();
        GrafoPonderado grafo = DatosCompartidos.obtenerGrafoPonderado();

        String origenInput = txtOrigen.getText();
        String destinoInput = txtDestino.getText();

        try {
            int origen = Integer.parseInt(origenInput);
            int destino = Integer.parseInt(destinoInput);
            List<Integer> rutaOptima = grafo.encontrarRutaEficiente(origen, destino);

            if (!rutaOptima.isEmpty()) {
                // Limpiar el modelo existente y agregar la nueva ruta óptima
                listModel.clear();
                listModel.addElement("Ruta óptima: " + rutaOptima.toString());
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró una ruta óptima.");
            }

        } catch (NumberFormatException f) {
            JOptionPane.showMessageDialog(this, "Ingrese números válidos para el origen y destino.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void BackTOMenu(){
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameMenuUsuario = new MenuUsuario();
                frameMenuUsuario.setSize(350, 300);
                frameMenuUsuario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameMenuUsuario.setLocationRelativeTo(null);
                frameMenuUsuario.setVisible(true);
                dispose();
            }
        });
    }
}
