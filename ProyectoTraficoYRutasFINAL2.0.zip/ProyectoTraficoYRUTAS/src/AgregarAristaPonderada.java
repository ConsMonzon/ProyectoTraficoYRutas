import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AgregarAristaPonderada extends JFrame {
    private JPanel panel1;
    private JTextField txtVerticeOrigen;
    private JTextField txtVerticeDestino;
    private JTextField txtPesoArista;
    private JButton btnMenuAdmin;
    private JButton btnAgregarAristaP;
    private JLabel lblTitulo;
    private JLabel lblTittuo2;
    private JLabel lblVerticeOrigen;
    private JLabel lblVerticeDestino;
    private JLabel lblPesoArista;

    public AgregarAristaPonderada() {
        //TITULO DE LA VENTANA
        super("AGREGAR ARISTA PONDERADA");
        setContentPane(panel1);
        btnAgregarAristaP.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarArista();
            }
        });
        btnMenuAdmin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BackTOMenu();
            }
        });
    }

    private void agregarArista(){
            GrafoPonderado grafo = DatosCompartidos.obtenerGrafoPonderado();

            String origenAristaStr = txtVerticeOrigen.getText().trim();
            String destinoAristaStr = txtVerticeDestino.getText().trim();
            String pesoAristaStr = txtPesoArista.getText().trim();

            if (origenAristaStr.isEmpty() || destinoAristaStr.isEmpty() || pesoAristaStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Los campos obligatorios no pueden estar vacíos.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int origenArista,destinoArista, pesoArista;

            try {
                origenArista = Integer.parseInt(origenAristaStr);
                destinoArista = Integer.parseInt(destinoAristaStr);
                pesoArista = Integer.parseInt(pesoAristaStr);
            } catch (NumberFormatException f) {
                JOptionPane.showMessageDialog(this, "Ingrese valores numéricos válidos para todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }


            grafo.agregarArista(origenArista, destinoArista, pesoArista);
            JOptionPane.showMessageDialog(null,"Arista agregada al grafo.");
            txtVerticeOrigen.setText("");
            txtVerticeDestino.setText("");
            txtPesoArista.setText("");
        }

    private void BackTOMenu(){
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameMenuAdmin = new MenuAdmin();
                frameMenuAdmin.setSize(350, 300);
                frameMenuAdmin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameMenuAdmin.setLocationRelativeTo(null);
                frameMenuAdmin.setVisible(true);
                dispose();
            }
        });
    }
}

