import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuAdmin extends JFrame {
    private JPanel panel1;
    private JLabel lblTitulo;
    private JTextField opcionSeleccionada;
    private JLabel lblOpcion1;
    private JLabel lblOpcion2;
    private JLabel lblOpcion3;
    private JLabel lblOpcion5;
    private JLabel lblOpcionSalir;
    private JLabel lblOrden;
    private JLabel lblOpcion4;
    private JButton btnSeleccion;
    private ControlAcceso controlAcceso;

    public MenuAdmin() {
        //TITULO DE LA VENTANA
        super("MENU ADMINISTRADOR");
        setContentPane(panel1);
        controlAcceso = ControlAcceso.obtenerInstancia();

        //MENU
        opcionSeleccionada.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String opcionA = opcionSeleccionada.getText();
                switch (opcionA) {
                    case "1":
                        agregarDatos();
                        break;
                    case "2":
                        agregarAristaPonderada();
                        break;
                    case "3":
                        agregarAlertaColaPrioridad();
                        break;
                    case "4":
                        mostrarDatos();
                        break;
                    case "5":
                        gestionarUsuarios();
                        break;
                    case "0":
                        salir();
                        break;
                    default:
                        JOptionPane.showMessageDialog(null,"Opción no válida. Por favor, elija una opción del menú.");
                }
            }
        });
    }
    private void agregarDatos(){

        // ABRE VENTANA AGREGAR DATOS
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameAgrData = new AgregaDatos();
                frameAgrData.setSize(400, 400);
                frameAgrData.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameAgrData.setLocationRelativeTo(null);
                frameAgrData.setVisible(true);
                dispose();
            }
        });
    }

    private void agregarAristaPonderada(){

        // ABRE VENTANA AGREGAR ARISTA PONDERADA
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameAgrAP = new AgregarAristaPonderada();
                frameAgrAP.setSize(400, 400);
                frameAgrAP.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameAgrAP.setLocationRelativeTo(null);
                frameAgrAP.setVisible(true);
                dispose();
            }
        });
    }
    private void agregarAlertaColaPrioridad(){

        // ABRE VENTANA AGREGAR ALERTA COLA PRIORIDAD
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameAgrAlertaCP = new AgregarAlertaColaPrioridad();
                frameAgrAlertaCP.setSize(400, 350);
                frameAgrAlertaCP.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameAgrAlertaCP.setLocationRelativeTo(null);
                frameAgrAlertaCP.setVisible(true);
                dispose();
            }
        });
    }

    private void mostrarDatos(){

        // ABRE VENTANA AGREGAR ALERTA COLA PRIORIDAD
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameConsInfo = new ConsultaInfo();
                frameConsInfo.setSize(400, 350);
                frameConsInfo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameConsInfo.setLocationRelativeTo(null);
                frameConsInfo.setVisible(true);
                dispose();
            }
        });
    }
    private void gestionarUsuarios(){
        // ABRE VENTANA MENU GESTIONAR USUARIOS
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameMenuGU = new GestionarUsuarios();
                frameMenuGU.setSize(350, 300);
                frameMenuGU.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameMenuGU.setLocationRelativeTo(null);
                frameMenuGU.setVisible(true);
                dispose();
            }
        });
    }
    private void salir(){
        JOptionPane.showMessageDialog(null,"Saliendo del usuario actual...");
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameSalida = new Salida();
                frameSalida.setSize(350, 300);
                frameSalida.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameSalida.setLocationRelativeTo(null);
                frameSalida.setVisible(true);
                dispose();
            }
        });
    }

}
