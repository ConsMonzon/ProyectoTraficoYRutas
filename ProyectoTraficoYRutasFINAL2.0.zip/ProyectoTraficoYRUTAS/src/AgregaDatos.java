import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AgregaDatos extends JFrame {
    private JPanel panel1;
    private JLabel lblTitulo;
    private JLabel lblTitulo2;
    private JLabel lblRuta;
    private JTextField txtRuta;
    private JTextField txtVelocidad;
    private JTextField txtDensidad;
    private JLabel lblVelocidad;
    private JLabel lblDensidad;
    private JLabel lblPreguntaAccidente;
    private JCheckBox checkBoxAccidente;
    private JLabel lblTipoAccidente;
    private JTextField txtTipoAccidente;
    private JLabel lblDescripAccidente;
    private JTextField txtDescripAccidente;
    private JButton btnAgregarDatos;
    private JButton btnMenuAdmin;

    public AgregaDatos() {
        super("AGREGAR DATOS TRÁFICO");
        setContentPane(panel1);

        btnAgregarDatos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarDatos();
            }
        });

        btnMenuAdmin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BackTOMenu();
            }
        });
    }

    private void agregarDatos() {
        boolean accidente = checkBoxAccidente.isSelected();
        String nombreRuta = txtRuta.getText();
        String velocidadStr = txtVelocidad.getText().trim();
        String densidadStr = txtDensidad.getText().trim();

        if (nombreRuta.isEmpty() || velocidadStr.isEmpty() || densidadStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Los campos obligatorios no pueden estar vacíos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int velocidad, densidad;

        try {
            velocidad = Integer.parseInt(velocidadStr);
            densidad = Integer.parseInt(densidadStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese valores numéricos válidos para velocidad y densidad.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (accidente && (txtTipoAccidente.getText().isEmpty() || txtDescripAccidente.getText().isEmpty())) {
            JOptionPane.showMessageDialog(this, "Debe ingresar el tipo y la descripción del accidente reportado","Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        TablaHashTrafico tablaHashTrafico = DatosCompartidos.obtenerTablaHashTrafico();
        ColaPrioridadAlertas colaAlertas = DatosCompartidos.obtenerColaAlertas();

        if (accidente) {
            String tipoIncidente = txtTipoAccidente.getText();
            String descripcionIncidente = txtDescripAccidente.getText();
            colaAlertas.agregarAlerta(new ColaPrioridadAlertas.Alerta(tipoIncidente, descripcionIncidente));
            JOptionPane.showMessageDialog(this, "Incidente reportado. Gracias por tu colaboración.");
        }

        tablaHashTrafico.agregarDatos(nombreRuta, velocidad, densidad, accidente);
        JOptionPane.showMessageDialog(this, "Datos de tráfico agregados exitosamente.");
        txtRuta.setText("");
        txtVelocidad.setText("");
        txtDensidad.setText("");
        txtTipoAccidente.setText("");
        txtDescripAccidente.setText("");
        checkBoxAccidente.setSelected(false);
    }

    private void BackTOMenu(){
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameMenuAdmin = new MenuAdmin();
                frameMenuAdmin.setSize(350, 300);
                frameMenuAdmin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameMenuAdmin.setLocationRelativeTo(null);
                frameMenuAdmin.setVisible(true);
                dispose();
            }
        });
    }
}