import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GestionarUsuarios extends JFrame{

    private JPanel panel1;
    private JLabel lblTitulo;
    private JLabel lblAgregarUsuario;
    private JLabel lblEliminarUsuario;
    private JLabel lblMenuAdmin;
    private JLabel lblSeleccion;
    private JTextField opcionSeleccionada;
    private ControlAcceso controlAcceso;


    public GestionarUsuarios() {
        //TITULO DE LA VENTANA
        super("MENU GESTIÓN USUARIOS");
        setContentPane(panel1);
        controlAcceso = ControlAcceso.obtenerInstancia();

        opcionSeleccionada.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String opcionA = opcionSeleccionada.getText();
                switch (opcionA) {
                    case "1":
                        agregarUsuario();
                        break;
                    case "2":
                        modificarUsuario();
                        break;
                    case "3":
                        eliminarUsuario();
                        break;
                    case "0":
                        BackTOMenu();
                        break;
                    default:
                        JOptionPane.showMessageDialog(null,"Opción no válida. Por favor, elija una opción del menú.");
                }
            }
        });
    }
    private void agregarUsuario(){
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameAgrUsuario = new AgregarUsuario();
                frameAgrUsuario.setSize(400, 350);
                frameAgrUsuario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameAgrUsuario.setLocationRelativeTo(null);
                frameAgrUsuario.setVisible(true);
                dispose();
            }
        });
    }
    private void modificarUsuario(){
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameModifUsuario = new ModificarUsuario();
                frameModifUsuario.setSize(400, 350);
                frameModifUsuario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameModifUsuario.setLocationRelativeTo(null);
                frameModifUsuario.setVisible(true);
                dispose();
            }
        });
    }
    private void eliminarUsuario(){
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameElimUsuario = new EliminarUsuario();
                frameElimUsuario.setSize(400, 300);
                frameElimUsuario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameElimUsuario.setLocationRelativeTo(null);
                frameElimUsuario.setVisible(true);
                dispose();
            }
        });
    }
    private void BackTOMenu(){
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameMenuAdmin = new MenuAdmin();
                frameMenuAdmin.setSize(350, 300);
                frameMenuAdmin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameMenuAdmin.setLocationRelativeTo(null);
                frameMenuAdmin.setVisible(true);
                dispose();
            }
        });
    }
}