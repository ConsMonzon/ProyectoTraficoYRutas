import java.util.PriorityQueue;

public class ColaPrioridadAlertas {
    private PriorityQueue<Alerta> colaPrioridad;

    public ColaPrioridadAlertas() {
        colaPrioridad = new PriorityQueue<>();
    }

    public void agregarAlerta(Alerta alerta) {
        colaPrioridad.offer(alerta);
    }



    // Clase para representar una alerta
    public static class Alerta implements Comparable<Alerta> {
        private String tipo;
        private String mensaje;

        public Alerta(String tipo, String mensaje) {
            this.tipo = tipo;
            this.mensaje = mensaje;
        }

        @Override
        public int compareTo(Alerta otraAlerta) {
            // Define la prioridad de las alertas según sea necesario
            // Puedes comparar por tipo, tiempo, gravedad, etc.
            // En este caso, se ordena alfabéticamente por tipo de alerta
            return this.tipo.compareTo(otraAlerta.tipo);
        }
    }
}