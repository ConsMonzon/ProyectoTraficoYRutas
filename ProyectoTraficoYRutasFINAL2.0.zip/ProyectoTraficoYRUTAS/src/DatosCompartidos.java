public class DatosCompartidos {
    private static TablaHashTrafico tablaHashTrafico = new TablaHashTrafico();
    private static GrafoPonderado grafo = new GrafoPonderado(5);
    private static ColaPrioridadAlertas colaAlertas = new ColaPrioridadAlertas();

    public static TablaHashTrafico obtenerTablaHashTrafico() {
        return tablaHashTrafico;
    }

    public static GrafoPonderado obtenerGrafoPonderado() {
        return grafo;
    }
    public static ColaPrioridadAlertas obtenerColaAlertas() {
        return colaAlertas;
    }
}