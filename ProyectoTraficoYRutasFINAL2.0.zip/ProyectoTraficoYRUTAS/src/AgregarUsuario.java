import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AgregarUsuario extends JFrame {
    private JPanel panel1;
    private JTextField txtNombreNuevoUsuario;
    private JTextField txtNuevaContraseña;
    private JCheckBox checkBoxAdmin;
    private JButton btnAgregarUsuario;
    private JButton btnMenuGU;
    private JLabel lblTitulo1;
    private JLabel lblTitulo2;
    private JLabel lblNombreUsuario;
    private JLabel lblContraseña;
    private JLabel lblBooleanAdmin;

    public AgregarUsuario() {
        super("AGREGAR USUARIO");
        setContentPane(panel1);

        btnAgregarUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarDatos();
            }
        });

        btnMenuGU.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BackTOMenu();
            }
        });
    }
    private void agregarDatos() {
        ControlAcceso controlAcceso = ControlAcceso.obtenerInstancia();

        boolean esAdmin = checkBoxAdmin.isSelected();
        String nuevoNombre = txtNombreNuevoUsuario.getText();
        String nuevaContraseña = txtNuevaContraseña.getText();

        if (nuevoNombre.isEmpty() || nuevaContraseña.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Los campos obligatorios no pueden estar vacíos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (esAdmin) {
            JOptionPane.showMessageDialog(this, "El nuevo usuario es administrador");
        }

        controlAcceso.agregarUsuario(nuevoNombre, nuevaContraseña, esAdmin);
        JOptionPane.showMessageDialog(null,"Usuario agregado exitosamente.");
        txtNombreNuevoUsuario.setText("");
        txtNuevaContraseña.setText("");
        checkBoxAdmin.setSelected(false);
    }

    private void BackTOMenu(){
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frameMenuGU = new GestionarUsuarios();
                frameMenuGU.setSize(400, 350);
                frameMenuGU.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frameMenuGU.setLocationRelativeTo(null);
                frameMenuGU.setVisible(true);
                dispose();
            }
        });
    }
}
