import java.util.HashMap;

public class TablaHashTrafico {
    private HashMap<String, InformacionTrafico> tablaHash;

    public TablaHashTrafico() {
        tablaHash = new HashMap<>();
    }

    public void agregarDatos(String clave, int velocidadTrafico, int densidadVehiculos, boolean accidente) {
        InformacionTrafico info = new InformacionTrafico(velocidadTrafico, densidadVehiculos, accidente);
        tablaHash.put(clave, info);
    }

    public InformacionTrafico obtenerDatos(String clave) {
        return tablaHash.get(clave);
    }

    public void eliminarDatos(String clave) {
        tablaHash.remove(clave);
    }

    // Clase interna para almacenar la información del tráfico
    public class InformacionTrafico {
        private int velocidadTrafico;
        private int densidadVehiculos;
        private boolean accidente;

        public InformacionTrafico(int velocidadTrafico, int densidadVehiculos, boolean accidente) {
            this.velocidadTrafico = velocidadTrafico;
            this.densidadVehiculos = densidadVehiculos;
            this.accidente = accidente;
        }

        // Métodos para obtener información específica
        public int obtenerVelocidadTrafico() {
            return velocidadTrafico;
        }

        public int obtenerDensidadVehiculos() {
            return densidadVehiculos;
        }

        public boolean hayAccidente() {
            return accidente;
        }
    }
}