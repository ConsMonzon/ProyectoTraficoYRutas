import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Salida extends JFrame{
    private JPanel panel1;
    private JTextField opcion;
    private JLabel lblSalir;
    private JLabel lblCredenciales;
    private JLabel lblOpcion;

    public Salida() {
        super("SALIDA");
        setContentPane(panel1);

        opcion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String opcionselec = opcion.getText();
                switch (opcionselec) {
                    case "1":
                        SwingUtilities.invokeLater(new Runnable() {
                            @Override
                            public void run() {
                                JFrame frameLogin = new LogIn();
                                frameLogin.setSize(450,300);
                                frameLogin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                frameLogin.setLocationRelativeTo(null);
                                frameLogin.setVisible(true);
                                dispose();
                            }
                        });
                        break;
                    case "0":
                        dispose();
                        break;
                    default:
                        System.out.println("Opción no válida. Por favor, elija una opción del menú.");
                }
            }
        });
    }
}
